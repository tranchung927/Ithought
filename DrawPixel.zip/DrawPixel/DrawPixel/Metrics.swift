//
//  Metrics.swift
//  DrawPixel
//
//  Created by ChungTran on 12/27/17.
//  Copyright © 2017 ChungTran. All rights reserved.
//

import UIKit

public struct Metrics {
	public static let regular: CGFloat = 20
	public static let large: CGFloat = 30
}
